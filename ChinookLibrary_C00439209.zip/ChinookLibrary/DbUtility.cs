﻿// Colin Lauret 
// C00439209 
// CMPS 358 .NET/C# Programming
// Chinook Library Assignment

namespace ChinookLibrary.Models;

public static class DbUtility
{
    //  i. Return a sorted list of the names of the genres of music that are listed in the database.
    public static List<string> GetSortedGenres()
    {
        using var db = new ChinookContext();

        var results =
            from genre in db.Genres
            orderby genre.Name
            select genre.Name;

        if (!results.Any())
            return null;

        return results.ToList();
    }

    
    //  ii. Return a sorted list of the names of the artists that are listed in the database.
    public static List<string> GetSortedArtists()
    {
        using var db = new ChinookContext();

        var results =
            from artist in db.Artists
            orderby artist.Name
            select artist.Name;

        if (!results.Any())
            return null;

        return results.ToList();
    }

    
    // iii. Given a genre, return a lists of the tracks available that includes the track id, 
    // name of the track, the name of the artist and its price.
    public static List<string> ListSongsByGenre(string genre)
    {
        if (genre == null) return new List<string>();
        
        using var db = new ChinookContext();
        var genreId = GenreID(genre, db);

        if (genreId == 0)
        {
            return new List<string>(); 
        }

        var results =
            from song in db.Tracks
            join album in db.Albums on song.AlbumId equals album.AlbumId
            join artist in db.Artists on album.ArtistId equals artist.ArtistId
            where song.GenreId == genreId
            select new
            {
                song.TrackId,
                song.Name,
                ArtistName = artist.Name,
                song.UnitPrice
            };

        var list = new List<string>();

        if (!results.Any())
            return list;
        else
            foreach (var track in results)
                list.Add($"{track.TrackId}::{track.Name}::{track.ArtistName}::{track.UnitPrice}");

        return list;
    }

    // Additional method for task 3 to convert the genre name to a genre ID
    static int GenreID(string genreName, ChinookContext db)
    {
        var results =
            from genre in db.Genres
            where genreName == genre.Name
            select genre;

        if (results.Any())
            return results.First().GenreId;
        
        return 0;
    }
    
    
    // iv. Given an artist’s name, return a list of tracks available by that artist that includes the track id,
    // name of the track and its price. 
    public static List<string> ListSongsByArtist(string artistName)
    {
        if (artistName == null) return new List<string>();

        using var db = new ChinookContext();

        var results =
            from song in db.Tracks
            join album in db.Albums on song.AlbumId equals album.AlbumId
            join artist in db.Artists on album.ArtistId equals artist.ArtistId
            where artist.Name == artistName
            select new
            {
                song.TrackId,
                song.Name,
                song.UnitPrice
            };

        var list = new List<string>();

        if (!results.Any())
            return list;
        else
            foreach (var track in results)
                list.Add($"{track.TrackId}::{track.Name}::{track.UnitPrice}");

        return list;
    }
    
    
    // v. Return a sorted lists of the composers of tracks and the count of the number of tracks by the composer
    public static Dictionary<string, int> ListComposers()
    {
        using var db = new ChinookContext();
        
        var composerTrackCounts = new Dictionary<string, int>();
        var tracks = db.Tracks.ToList();

        foreach (var song in tracks)
        {
            if (song.Composer != null)
            {
                if (composerTrackCounts.ContainsKey(song.Composer))
                {
                    composerTrackCounts[song.Composer]++;
                }
                else
                {
                    composerTrackCounts[song.Composer] = 1; 
                }
            }
        }
        
        var sortedComposers = new Dictionary<string, int>();
        foreach (var pair in composerTrackCounts.OrderBy(x => x.Key))
        {
            sortedComposers.Add(pair.Key, pair.Value);
        }

        return sortedComposers;
    }
}
