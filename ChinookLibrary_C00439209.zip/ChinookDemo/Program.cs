﻿// Colin Lauret 
// C00439209 
// CMPS 358 .NET/C# Programming
// Chinook Library Assignment

using ChinookLibrary.Models;

while (true)
{
    // Display menu to user to select a database query
    string choice = Menu();
    
    switch (choice)
    {
        case "0":
            return;
        case "1":
            TaskOne();
            break;
        case "2":
            TaskTwo();
            break;
        case "3":
            TaskThree();
            break;
        case "4":
            TaskFour();
            break;
        case "5":
            TaskFive();
            break;
        case "6":
            TaskOne();
            TaskTwo();
            TaskThree();
            TaskFour();
            TaskFive();
            break;
        default:
            Console.WriteLine("Invalid Input");
            break;
    }
}

//  i. Return a sorted list of the names of the genres of music that are listed in the database.
static void TaskOne()
{
    var results = DbUtility.GetSortedGenres();
    Console.WriteLine($"\nList of genres");
    foreach (var c in results)
        Console.Write($"{c}, ");
        
    Console.WriteLine();
}

//  ii. Return a sorted list of the names of the artists that are listed in the database.
static void TaskTwo()
{
    var results = DbUtility.GetSortedArtists();
    Console.WriteLine($"\nList of artists");
        
    foreach (var c in results)
        Console.Write($"{c}, ");
        
    Console.WriteLine();
}

// iii. Given a user entered genre, return a lists of the tracks matching that genre including the track id, 
// name of the track, the name of the artist and its price.
static void TaskThree()
{
    Console.Write("\nEnter a genre: ");
    var genre = Console.ReadLine();
    var results = DbUtility.ListSongsByGenre(genre);
        
    if (results.Count == 0)
    {
        Console.WriteLine("No songs found for this genre.");
    }
    else
    {
        foreach (var song in results)
            Console.WriteLine(song);
    }
    Console.WriteLine();
}

// iv. Given a user entered artist name, return a lists of the tracks created by the artists including the
// track id, name of the track, the name of the artist and its price.
static void TaskFour()
{
    Console.Write("\nEnter an artist name: ");
    var artistName = Console.ReadLine();
    var results = DbUtility.ListSongsByArtist(artistName);
        
    if (results.Count == 0)
    {
        Console.WriteLine("No songs found for this artist.");
    }
    else
    {
        foreach (var song in results)
            Console.WriteLine(song);
    }
    Console.WriteLine();
}

// v. Return a sorted lists of the composers of tracks and the count of the number of tracks by the composer
static void TaskFive()
{
    var composersList = DbUtility.ListComposers();

    Console.WriteLine("List of composers and their track counts:");
    foreach (var composer in composersList)
    {
        Console.Write($"{composer.Key}-{composer.Value}, ");
    }
    Console.WriteLine();
}

// Method to display menu to user to select query 
static string Menu()
{
    Console.WriteLine();
    Console.WriteLine("Please select an option from the menu below and press Enter.");
    Console.WriteLine("For options requiring additional input, follow the prompts accordingly.");
    Console.WriteLine("1 - List all of the genres of music in the database");
    Console.WriteLine("2 - List all of the artists in the database");
    Console.WriteLine("3 - List all of the songs and their information of a given genre");
    Console.WriteLine("4 - List all the songs and their information of a given artist");
    Console.WriteLine("5 - List all of the composers and the number of tracks created");
    Console.WriteLine("6 - Display all queries on the database at once");
    Console.WriteLine("0 - Exit");
    return Console.ReadLine();
}
